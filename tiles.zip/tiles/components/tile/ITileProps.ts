import { ITileInfo } from '..';

export interface ITileProps {
  item: ITileInfo;
  height: number;
  tileWidth:number;
  iconFontSize:number;
  tileBGColor:string;
}
