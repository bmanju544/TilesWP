/* tslint:disable */
require("./Tile.module.css");
const styles = {
  tile: 'tile_58061a6e',
  'ms-Grid': 'ms-Grid_58061a6e',
  tileIcon: 'tileIcon_58061a6e',
  tileTitle: 'tileTitle_58061a6e',
  overflow: 'overflow_58061a6e'
};

export default styles;
/* tslint:enable */