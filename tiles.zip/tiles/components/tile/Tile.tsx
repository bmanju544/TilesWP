import * as React from 'react';
import styles from './Tile.module.scss';
import { ITileProps } from '.';
import { Icon } from 'office-ui-fabric-react/lib/components/Icon';

export class Tile extends React.Component<ITileProps, {}> {
  public render(): React.ReactElement<ITileProps> {
    const tileStyle: React.CSSProperties = {};
    const tileBGStyle: React.CSSProperties = {};
    const iconStyle: React.CSSProperties = {};
    if (this.props.height) {
      tileStyle.height = `${this.props.height}px`;
    }
    if (this.props.tileWidth) {
      tileStyle.width = `${this.props.tileWidth}px`;
    }
    if (this.props.tileBGColor) {
      tileBGStyle.backgroundColor = `${this.props.tileBGColor}`;
    }
    if (this.props.iconFontSize) {
      iconStyle.fontSize = `${this.props.iconFontSize}px`;
    }

    return (
      <div className={styles.tile} style={tileStyle}>
        <a href={this.props.item.url}
          target={this.props.item.target}
          title={this.props.item.title} style={tileBGStyle}>
          <div className={styles.tileIcon}>
            <Icon iconName={this.props.item.icon} style={iconStyle} />
            {/* <img src={this.props.item.icon} height={tileStyle.height} width={"100px"} /> */}
          </div>
          <div className={styles.tileTitle}>
            {this.props.item.title}
          </div>

          <div className={styles.overflow}>
            {this.props.item.description}
          </div>
        </a>
      </div>
    );
  }
}
