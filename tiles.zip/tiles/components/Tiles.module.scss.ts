/* tslint:disable */
require("./Tiles.module.css");
const styles = {
  tiles: 'tiles_90dbbc13',
  message: 'message_90dbbc13',
  error: 'error_90dbbc13',
  tilesList: 'tilesList_90dbbc13'
};

export default styles;
/* tslint:enable */